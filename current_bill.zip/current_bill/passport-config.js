const LocalStrategy = require('passport-local').Strategy
const bcrypt = require('bcrypt')

function initialize(passport, getUserByEmail) {
  const authenticateUser = async (cs_name, cs_id, done) => {
    const user = getUserByEmail(cs_id)
    if (user!=true) {
      return done(null, false, { message: 'No user with that email' })
    }

    try {
      
        return done(null, user)
      } 
        
     catch (e) {
      return done(e)
    }
  }

  passport.use(new LocalStrategy({ usernameField: 'us_id' }, authenticateUser))
  passport.serializeUser((user, done) => done(null, user._id))
}

module.exports = initialize