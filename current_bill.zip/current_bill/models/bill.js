const mongoose = require("mongoose");

const billSchema = new mongoose.Schema({
	service_id:{
		type:String
	},
	units:{
		type:String
	},
	payer:{
		type: mongoose.Schema.Types.ObjectId,
		ref: "user",
	}
});

const Bill = mongoose.model("Bill", billSchema);
module.exports = Bill;