const {MongoClient}=require('mongodb')
const databaseName ="bills-api"
const connectionURL="mongodb://localhost:27017/"

const  client=new MongoClient(connectionURL)
async function connection(){
    let result =await client.connect()
    return result.db(databaseName)
}


async function addRecord(record){
    let db=await connection()
    let response=await db.collection("bills").insertOne(record)
    return response

}
async function deleteAll(){
    let db=await connection()
    let response=await db.collection("bills").deleteMany()
    return response

}
//deleteAll()


async function findAllBills(){
    let db=await connection()
    let response =await db.collection("bills").find({})
    console.log(response)
    return response
}


module.exports={addRecord,findAllBills}