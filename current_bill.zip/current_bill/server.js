
const express = require('express')
const app = express()

const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const expressLayouts = require("express-ejs-layouts");
const db=require("./db.js")




const initializePassport = require('./passport-config')
initializePassport(
  passport,
   async cs_id=> await db.findConsumer(cs_id)
  //id => users.find(user => user.id === id)
)



app.use(express.static(__dirname+"/assets"))
app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: true }))
app.use(flash());
app.use(express.json());
app.use(session({
  secret:"secret",
  resave: false,
  saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))
app.set('view-engine', 'ejs')

app.get('/',  (req, res) => {
  res.sendFile(__dirname+"/assets/home.html")
})

app.get('/login', checkNotAuthenticated, (req, res) => {
  res.sendFile(__dirname+"/assets/customer_details.htm")
})

app.post('/login', checkNotAuthenticated,(req,res)=>{
  console.log(req.body)
  passport.authenticate('local')
  res.redirect("/generatebill")
}) 

app.get('/generatebill', (req, res) => {
  res.render('BillDetails.ejs')

})


app.post('/generatebill', async (req, res) => {
  try {
    data=req.body
    data.total=data.units*data.cperunit  
    let Total=data.units*data.cperunit  
    db.addRecord(data)
    console.log(data)
    
    res.render("Bill_Cal.ejs",{Total})
  } catch(e) {
    console.log(e)
    res.redirect('/')
  }
})


app.get('/generatebillall/', async (req, res) => {
  k=await db.findAllBills()
  allBills=await k.toArray()
  console.log(allBills)
  res.render("all.ejs",allBills)
})




function checkAuthenticated(req, res, next) {
  console.log(req.isAuthenticated() +"in check")
  if (req.isAuthenticated()) {
    
    return next()
  }

  res.redirect('/login')
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect('/')
  }
  next()
}

app.listen(3000,()=>{
  console.log("app is running on http://localhost:3000")
})
